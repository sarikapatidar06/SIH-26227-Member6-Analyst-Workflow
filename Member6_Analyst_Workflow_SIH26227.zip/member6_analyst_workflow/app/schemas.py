from typing import Literal
from pydantic import BaseModel, Field

Decision = Literal["CONFIRMED", "REJECTED", "UNCERTAIN"]

class ReviewRequest(BaseModel):
    decision: Decision
    comment: str = Field(default="", max_length=2000)
    analyst: str = Field(default="analyst", min_length=1, max_length=100)

class FeedbackRequest(BaseModel):
    feedback_type: Literal["CORRECT", "INCORRECT", "NEEDS_REVIEW", "OTHER"]
    comment: str = Field(default="", max_length=2000)
    actor: str = Field(default="analyst", min_length=1, max_length=100)
