import csv
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from html import escape

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from .database import get_conn, BASE_DIR

EXPORT_DIR = BASE_DIR / "exports"
EXPORT_DIR.mkdir(exist_ok=True)

def now():
    return datetime.now(timezone.utc).isoformat()

def row_dict(row):
    return dict(row) if row else None

def get_finding(conn, finding_id):
    return conn.execute("SELECT * FROM findings WHERE id=?", (finding_id,)).fetchone()

def get_full(conn, finding_id):
    f = get_finding(conn, finding_id)
    if not f:
        return None
    observations = conn.execute(
        "SELECT * FROM observations WHERE finding_id=? ORDER BY observation_date",
        (finding_id,)
    ).fetchall()
    provenance = conn.execute(
        "SELECT * FROM provenance WHERE finding_id=? ORDER BY id DESC",
        (finding_id,)
    ).fetchall()
    audit = conn.execute(
        "SELECT * FROM audit_log WHERE finding_id=? ORDER BY timestamp",
        (finding_id,)
    ).fetchall()
    feedback = conn.execute(
        "SELECT * FROM feedback WHERE finding_id=? ORDER BY timestamp",
        (finding_id,)
    ).fetchall()
    return {
        "finding": row_dict(f),
        "timeline": [row_dict(x) for x in observations],
        "provenance": [row_dict(x) for x in provenance],
        "audit_log": [row_dict(x) for x in audit],
        "feedback": [row_dict(x) for x in feedback],
    }

def add_audit(conn, finding_id, action, actor, details):
    conn.execute(
        "INSERT INTO audit_log(finding_id, action, actor, details, timestamp) VALUES(?,?,?,?,?)",
        (finding_id, action, actor, details, now())
    )

def review_finding(finding_id, decision, comment, analyst):
    conn = get_conn()
    f = get_finding(conn, finding_id)
    if not f:
        conn.close()
        return None
    timestamp = now()
    conn.execute("""
        UPDATE findings
        SET review_status=?, review_comment=?, reviewed_by=?, reviewed_at=?, updated_at=?
        WHERE id=?
    """, (decision, comment, analyst, timestamp, timestamp, finding_id))
    add_audit(conn, finding_id, f"REVIEW_{decision}", analyst, comment or "No comment")
    conn.commit()
    result = get_full(conn, finding_id)
    conn.close()
    return result

def add_feedback(finding_id, feedback_type, comment, actor):
    conn = get_conn()
    if not get_finding(conn, finding_id):
        conn.close()
        return None
    conn.execute("""
        INSERT INTO feedback(finding_id, feedback_type, comment, actor, timestamp)
        VALUES(?,?,?,?,?)
    """, (finding_id, feedback_type, comment, actor, now()))
    add_audit(conn, finding_id, "FEEDBACK", actor, f"{feedback_type}: {comment}")
    conn.commit()
    result = get_full(conn, finding_id)
    conn.close()
    return result

def export_finding(finding_id, fmt):
    conn = get_conn()
    data = get_full(conn, finding_id)
    conn.close()
    if not data:
        return None

    stem = f"finding_{finding_id}"
    if fmt == "csv":
        path = EXPORT_DIR / f"{stem}.csv"
        with path.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow(["section", "field", "value"])
            for k, v in data["finding"].items():
                writer.writerow(["finding", k, v])
            for obs in data["timeline"]:
                for k, v in obs.items():
                    writer.writerow(["timeline", k, v])
            for p in data["provenance"]:
                for k, v in p.items():
                    writer.writerow(["provenance", k, v])
            for a in data["audit_log"]:
                for k, v in a.items():
                    writer.writerow(["audit_log", k, v])
        return path

    if fmt == "geojson":
        path = EXPORT_DIR / f"{stem}.geojson"
        finding = data["finding"]
        geometry = json.loads(finding["geometry_json"]) if finding["geometry_json"] else None
        feature = {
            "type": "Feature",
            "geometry": geometry,
            "properties": {
                "finding_id": finding["id"],
                "site_id": finding["site_id"],
                "change_class": finding["change_class"],
                "confidence": finding["confidence"],
                "review_status": finding["review_status"],
                "review_comment": finding["review_comment"],
            }
        }
        path.write_text(json.dumps(feature, indent=2), encoding="utf-8")
        return path

    if fmt == "html":
        path = EXPORT_DIR / f"{stem}.html"
        f = data["finding"]
        rows = "".join(
            f"<tr><td>{escape(str(o['observation_date']))}</td>"
            f"<td>{escape(str(o['sensor']))}</td>"
            f"<td>{escape(str(o['source_image']))}</td>"
            f"<td>{escape(str(o['quality']))}</td>"
            f"<td>{escape(str(o['notes']))}</td></tr>"
            for o in data["timeline"]
        )
        audit = "".join(
            f"<li>{escape(a['timestamp'])} — <b>{escape(a['action'])}</b> — "
            f"{escape(a['actor'])}: {escape(a['details'] or '')}</li>"
            for a in data["audit_log"]
        )
        p = data["provenance"][0] if data["provenance"] else {}
        html = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>Auditable Finding {f['id']}</title>
<style>body{{font-family:Arial;max-width:1000px;margin:40px auto;line-height:1.5}}
table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #ccc;padding:8px;text-align:left}}
.card{{border:1px solid #ddd;border-radius:10px;padding:16px;margin:12px 0}}</style></head>
<body><h1>Auditable Satellite Finding</h1>
<div class="card"><b>Finding:</b> {f['id']}<br>
<b>Site:</b> {escape(f['site_id'])}<br>
<b>Class:</b> {escape(f['change_class'])}<br>
<b>Confidence:</b> {f['confidence']}<br>
<b>Review:</b> {escape(f['review_status'])}<br>
<b>Analyst:</b> {escape(str(f['reviewed_by'] or ''))}<br>
<b>Comment:</b> {escape(str(f['review_comment'] or ''))}</div>
<h2>Timeline</h2><table><tr><th>Date</th><th>Sensor</th><th>Source</th><th>Quality</th><th>Notes</th></tr>{rows}</table>
<h2>Provenance</h2><div class="card">{escape(str(p))}</div>
<h2>Audit Log</h2><ul>{audit}</ul>
</body></html>"""
        path.write_text(html, encoding="utf-8")
        return path

    if fmt == "pdf":
        path = EXPORT_DIR / f"{stem}.pdf"
        f = data["finding"]
        c = canvas.Canvas(str(path), pagesize=A4)
        width, height = A4
        y = height - 50
        c.setFont("Helvetica-Bold", 16)
        c.drawString(40, y, "Auditable Satellite Finding")
        y -= 30
        c.setFont("Helvetica", 10)
        lines = [
            f"Finding ID: {f['id']}",
            f"Site: {f['site_id']}",
            f"Change class: {f['change_class']}",
            f"Confidence: {f['confidence']}",
            f"Review: {f['review_status']}",
            f"Reviewed by: {f['reviewed_by'] or ''}",
            f"Comment: {f['review_comment'] or ''}",
            "",
            "Timeline:"
        ]
        for o in data["timeline"]:
            lines.append(
                f"{o['observation_date']} | {o['sensor']} | {o['source_image']} | quality={o['quality']}"
            )
        lines += ["", "Audit Log:"]
        for a in data["audit_log"]:
            lines.append(f"{a['timestamp']} | {a['action']} | {a['actor']} | {a['details']}")
        for line in lines:
            if y < 50:
                c.showPage()
                y = height - 50
            c.drawString(40, y, str(line)[:120])
            y -= 15
        c.save()
        return path

    raise ValueError("Unsupported format")
