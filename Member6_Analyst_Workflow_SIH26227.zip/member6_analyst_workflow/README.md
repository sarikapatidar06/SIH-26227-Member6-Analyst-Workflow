# Member 6 — Analyst Workflow + Export

SIH 2026 PS 26227

This module covers the Member 6 scope:
- Confirm / Reject / Uncertain analyst review
- Analyst comments and feedback
- Timeline / multi-date observation view
- Evidence and provenance
- Audit log
- CSV / GeoJSON / HTML / PDF exports
- SQLite persistence
- FastAPI endpoints for integration with the team backend

## Run

```powershell
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

Open:
- API docs: http://127.0.0.1:8000/docs
- Health: http://127.0.0.1:8000/api/health

## Demo

The database is automatically seeded with one sample finding on first run.

Useful endpoints:
- GET  /api/findings
- GET  /api/findings/{finding_id}
- GET  /api/timeline/{finding_id}
- GET  /api/provenance/{finding_id}
- GET  /api/audit/{finding_id}
- POST /api/findings/{finding_id}/review
- POST /api/findings/{finding_id}/feedback
- GET  /api/export/{finding_id}?format=csv
- GET  /api/export/{finding_id}?format=geojson
- GET  /api/export/{finding_id}?format=html
- GET  /api/export/{finding_id}?format=pdf

## Review example

```json
{
  "decision": "CONFIRMED",
  "comment": "New built-up structure is visible in the later observation.",
  "analyst": "demo_analyst"
}
```

Allowed decisions:
- CONFIRMED
- REJECTED
- UNCERTAIN

## Integration with Member 4

Member 4 can keep the team's main FastAPI app and mount/import the routers from this module.
The important integration contract is the finding ID plus the analysis result:
change class, confidence, evidence, warnings, source imagery, dates, model/version, and geometry.

## Integration with Member 5

Member 5's dashboard can call these endpoints and render:
1. finding summary
2. timeline
3. evidence/provenance
4. Confirm / Reject / Uncertain controls
5. comment box
6. export buttons

This package intentionally keeps the UI minimal because the complete dashboard belongs to Member 5.
